=========
Changelog
=========

Version 1.0rc1
==============
(first release candidate for PyETo 1.0, released on TODO:insert date here)

* Initial release.
