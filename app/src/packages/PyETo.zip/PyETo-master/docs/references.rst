==========
References
==========
| Allen RG, Pereira LS, Raes D, Smith M (1998) Crop evapotranspiration.
|     Guidelines for computing crop water requirements. FAO irrigation and
|     drainage paper 56, FAO, Rome.
|
| Hargreaves GH, Samani ZA (1982) Estimating potential evapotranspiration.
|     Journal of the Irrigation and Drainage Division, ASCE, 108(3):225-230.
|
| Hargreaves GH, Samani ZA (1985) Reference crop evapotranspiration from
|    temperature. Applied Engineering in Agriculture 1(2):96-99
|    (doi 10.13031/2013.26773).
|
| Thornthwaite CW (1948) An approach toward a rational classification of
|     climate. Geographical Review, 38, 55-94.
