=======
License
=======

*PyETo* is licensed under the BSD 3-Clause "New" or "Revised" License.

License text
============

.. include:: ../LICENSE.txt